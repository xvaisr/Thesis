/**
 * BP, anthill strategy game
 * Experiments enumerator
 *
 * @author  xsimet00 Vojtech Simetka
 * @date    2012/04/01
 * @version 1
 * @file    graphic.EnumExperiments.java
 */
package graphic;

/**
 * Experiments enumerator
 * @author Vojtech Simetka
 *
 */
public enum EnumExperiments
{
	Resources,
	DeathMatch,
	TimeComplexity,
	Performance,
	Performance2,
	None,
}
