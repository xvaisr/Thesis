/**
 * BP, anthill strategy game
 * Teams enumerator
 *
 * @author  xsimet00 Vojtech Simetka
 * @date    2012/01/09
 * @version 1
 * @file    graphic.EnumTeams.java
 */
package graphic;

/**
 * Teams enumerator
 * @author Vojtech Simetka
 *
 */
public enum EnumTeams {
	a,
	b,
	c,
	d
}
