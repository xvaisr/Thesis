/**
 * BP, anthill strategy game
 * Alliances enumerator
 *
 * @author  xsimet00 Vojtech Simetka
 * @date    2012/02/09
 * @version 1
 * @file    graphic.EnumAlliances.java
 */
package graphic;

/**
 * Alliances enumerator
 * @author Vojtech Simetka
 *
 */
public enum EnumAlliances
{
	Alliance_1,
	Alliance_2,
	Alliance_3,
	Alliance_4
}
